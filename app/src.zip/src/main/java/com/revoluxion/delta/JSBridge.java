package com.revoluxion.delta;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.topjohnwu.superuser.Shell;

import java.util.List;

public class JSBridge {

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final WebView webView;

    public JSBridge(WebView webView) {
        this.webView = webView;
    }

    @JavascriptInterface
    public void runSuCommand(final String command) {
        new Thread(() -> {
            try {
                // Eksekusi perintah root menggunakan libsu
                List<String> result = Shell.cmd(command).exec().getOut();

                // Gabungkan output
                StringBuilder output = new StringBuilder();
                for (String line : result) {
                    output.append(line).append("\n");
                }

                // Escape quote agar aman untuk JavaScript
                String finalOutput = output.toString().replace("\"", "\\\"").replace("\n", "\\n");

                // Kirim hasil ke JavaScript di thread utama
                mainHandler.post(() -> {
                    webView.evaluateJavascript(
                        "window.onSuResult && window.onSuResult(\"" + finalOutput + "\");",
                        null
                    );
                });

            } catch (Exception e) {
                String err = e.getMessage();
                if (err == null) err = "Unknown error";
                final String escapedError = err.replace("\"", "\\\"");

                // Kirim error ke JavaScript
                mainHandler.post(() -> {
                    webView.evaluateJavascript(
                        "window.onSuResult && window.onSuResult(\"Error: " + escapedError + "\");",
                        null
                    );
                });
            }
        }).start();
    }
}
